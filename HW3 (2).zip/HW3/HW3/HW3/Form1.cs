﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW3
{
    public partial class Form1 : Form
    {
        List<Grader> graders = new List<Grader>();
        Grader selectedGrader = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            showGraders();
        }

        private void showGraders()
        {
            try
            {
                GradersEntities container = new GradersEntities();
                graders = container.Graders.ToList();
                var values = from c in graders
                             orderby c.GraderID
                             select new { c.GraderID, c.FirstName, c.LastName };
                dgvGraders.DataSource = values.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (selectedGrader != null)
                {
                    GradersEntities container = new GradersEntities();
                    var query = from c in container.Graders
                                where c.GraderID == selectedGrader.GraderID
                                select c;
                    Grader deletedGrader = query.FirstOrDefault();
                    if (deletedGrader != null)
                    {
                        container.Graders.Remove(deletedGrader);
                        container.SaveChanges();
                        showGraders();
                    }
                    
                }
            }
            catch (Exception ex)

            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Grader_Click(object sender, EventArgs e)
        {
            frmNewGrader form = new frmNewGrader();
            form.ShowDialog();

            //refresh the data grid view;

            showGraders();
        }
       

        private void lblpayment_Click(object sender, EventArgs e)
        {
            
        }

        private void dgvGraders_SelectionChanged_1(object sender, EventArgs e)
        {
            int selectGraderID = int.Parse(dgvGraders.CurrentRow.Cells[0].Value.ToString());
            try
            {
                GradersEntities container = new GradersEntities();
                var value = from c in container.Graders
                            where c.GraderID == selectGraderID
                            select c;
                selectedGrader = value.FirstOrDefault();
            }
            catch (Exception)
            {
                MessageBox.Show("Try it again.");
            }

            if (selectedGrader != null)
            {


                txtGraderId.Text = selectedGrader.GraderID.ToString();
                txtFirst.Text = selectedGrader.FirstName;
                txtLast.Text = selectedGrader.LastName;
                txtPay.Text = selectedGrader.HourlyPay.ToString();
                txtHours.Text = selectedGrader.Hours.ToString();
                txtDepartment.Text = selectedGrader.Department;
                txtPayment.Text = selectedGrader.CalculatePayment().ToString("c");
            }
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void dgvGraders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnGreater_Click(object sender, EventArgs e)
        {
            try
            {
                GradersEntities container = new GradersEntities();
                graders = container.Graders.ToList();
                var values = from c in graders
                             where c.Hours > 0
                             orderby c.GraderID
                             select new { c.GraderID, c.FirstName, c.LastName, c.Hours };
                dgvGraders.DataSource = values.ToList();


            }catch (Exception ex)
            {
                MessageBox.Show("Try it again." + ex.Message);
            }
        }

        private void btnEqualto_Click(object sender, EventArgs e)
        {
            GradersEntities container = new GradersEntities();
            graders = container.Graders.ToList();
            var values = from c in graders
                         where c.Hours == 0
                         orderby c.GraderID
                         select new { c.GraderID, c.FirstName, c.LastName, c.Hours };
            dgvGraders.DataSource = values.ToList();

        }

        private void txtPayment_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
