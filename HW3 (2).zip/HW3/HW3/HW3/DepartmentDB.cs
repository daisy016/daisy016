﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW3
{
    class DepartmentDB
    {
        public static List<Department> getAllDepartments()
        {
            List<Department> list = new List<Department>();
            string sqlString = "select * from departments ";

            //Get a connection object
            SqlConnection connection = DBConnection.getConnection();

            //prepare for a SQL statement
            SqlCommand selectCommand = new SqlCommand(sqlString, connection);
            SqlDataReader reader;

            //Execute the SQL command 
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);

                //throw the error to the presentation layer
                throw new Exception("database server error");
            }

            //populate the list of departments
            while (reader.Read()) // reader.Read() return true if there is a record
            {
                Department dp;
                try
                {
                    dp = new Department();
                    dp.DepartmentCode = (string)reader["DepartmentCode"]; //column name is case sensitive
                    dp.DepartmentName = (string)reader["DepartmentName"];

                }
                catch (Exception ex)
                {
                    //log the error.
                    Console.WriteLine(ex);
                        return null;

                    //throw the error to the presentation layer
                    throw new Exception("data error");

                }
                list.Add(dp);
            }
            try
            {
                connection.Close();

            }catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return list;
        }
    }
}
