﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HW3
{
    public class GraderDB
    {
        public static void deleteGrader(Grader grader)
        {
            //delete using embedded sql
            string sqlString = "delete from graders where GraderID = @id";
            //get a connection object
            SqlConnection connection = DBConnection.getConnection();
            //prepare for sql statement 
            try
            {
                SqlCommand deleteCommand = new SqlCommand(sqlString, connection);
                deleteCommand.Parameters.AddWithValue("@id", grader.GraderID);
                connection.Open();
                deleteCommand.ExecuteNonQuery();
            }catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);

                //throw the error to the presntation layer
                //throw new Exception("errors of creating a new client in db.");
                throw ex;

            }
            try
            {
                connection.Close();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);
            }

        }
        public static void addGrader(Grader grader)
        {
            //Insert using embedded sql
            string sqlString = "insert into graders values(@id, @firstname, @lastname, @pay, @hours, @dept ) ";

            //Get a connetion object
            SqlConnection connection = DBConnection.getConnection();
            //Prepare for a SQL statement 
            try
            {
                SqlCommand insertCommand = new SqlCommand(sqlString, connection);
                insertCommand.Parameters.AddWithValue("@id", grader.GraderID);
                insertCommand.Parameters.AddWithValue("@firstname", grader.FirstName);
                insertCommand.Parameters.AddWithValue("@lastname", grader.LastName);
                insertCommand.Parameters.AddWithValue("@pay", grader.HourlyPay);
                insertCommand.Parameters.AddWithValue("@hours", grader.Hours);
                insertCommand.Parameters.AddWithValue("@dept", grader.Department);
                connection.Open();
                insertCommand.ExecuteNonQuery();
            }catch (Exception ex)
            
            {
                //log the error.
                Console.WriteLine(ex);

                //throw the error to the presntation layer
                //throw new Exception("errors of creating a new client in db.");
                throw ex;
            }
            try
            {
                connection.Close();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);
            }
        }
        public static List<Grader> getAllGraders()
        {
            List<Grader> list = new List<Grader>();
            string sqlString = "select * from graders";


            //Get a connetion object
            SqlConnection connection = DBConnection.getConnection();

            //Prepare for a SQL statement 
            SqlCommand selectCommand = new SqlCommand(sqlString, connection);
            SqlDataReader reader;

            //Execute the SQL command
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);

                //throw the error to the presntation layer
                throw new Exception("database server error");
            }

            //populate the list of clients
            while (reader.Read()) //reader.Read() return true if there is a recored
            {
                Grader ct;
                try
                {
                    ct = new Grader();
                    ct.GraderID = (int)reader["GraderID"]; // column name is case sentitive 
                    ct.FirstName = (string)reader["FirstName"];
                    ct.LastName = (string)reader["LastName"];
                    ct.HourlyPay = (decimal)reader["HourlyPay"];
                    ct.Hours = (int)reader["Hours"];
                    ct.Department = (string)reader["Department"];
                }
                catch (Exception ex)
                {
                    //log the error.
                    Console.WriteLine(ex);
                    return null;

                    //throw the error to the presntation layer
                    throw new Exception("data error");

                }
                list.Add(ct);
            }

            try
            {
                connection.Close();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);
            }
            return list;
        }
    }
}
