﻿
namespace HW3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Grader = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dgvGraders = new System.Windows.Forms.DataGridView();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtGraderId = new System.Windows.Forms.TextBox();
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.txtPay = new System.Windows.Forms.TextBox();
            this.txtHours = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtLast = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lblpayment = new System.Windows.Forms.Label();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.btnGreater = new System.Windows.Forms.Button();
            this.btnEqualto = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGraders)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Grader
            // 
            this.btn_Grader.Location = new System.Drawing.Point(419, 25);
            this.btn_Grader.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_Grader.Name = "btn_Grader";
            this.btn_Grader.Size = new System.Drawing.Size(92, 47);
            this.btn_Grader.TabIndex = 0;
            this.btn_Grader.Text = "ADD GRADER";
            this.btn_Grader.UseVisualStyleBackColor = true;
            this.btn_Grader.Click += new System.EventHandler(this.btn_Grader_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(123, 59);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(5, 5);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // dgvGraders
            // 
            this.dgvGraders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGraders.Location = new System.Drawing.Point(37, 25);
            this.dgvGraders.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvGraders.Name = "dgvGraders";
            this.dgvGraders.RowHeadersWidth = 62;
            this.dgvGraders.RowTemplate.Height = 28;
            this.dgvGraders.Size = new System.Drawing.Size(345, 105);
            this.dgvGraders.TabIndex = 2;
            this.dgvGraders.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGraders_CellContentClick);
            this.dgvGraders.SelectionChanged += new System.EventHandler(this.dgvGraders_SelectionChanged_1);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(41, 283);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(99, 27);
            this.btnDelete.TabIndex = 3;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 146);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Grader ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 183);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(205, 156);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Hourly Pay";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(205, 185);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Hours";
            // 
            // txtGraderId
            // 
            this.txtGraderId.Location = new System.Drawing.Point(106, 147);
            this.txtGraderId.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtGraderId.Name = "txtGraderId";
            this.txtGraderId.ReadOnly = true;
            this.txtGraderId.Size = new System.Drawing.Size(68, 20);
            this.txtGraderId.TabIndex = 8;
            // 
            // txtFirst
            // 
            this.txtFirst.Location = new System.Drawing.Point(106, 183);
            this.txtFirst.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.ReadOnly = true;
            this.txtFirst.Size = new System.Drawing.Size(68, 20);
            this.txtFirst.TabIndex = 9;
            // 
            // txtPay
            // 
            this.txtPay.Location = new System.Drawing.Point(281, 152);
            this.txtPay.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPay.Name = "txtPay";
            this.txtPay.ReadOnly = true;
            this.txtPay.Size = new System.Drawing.Size(68, 20);
            this.txtPay.TabIndex = 10;
            // 
            // txtHours
            // 
            this.txtHours.Location = new System.Drawing.Point(281, 183);
            this.txtHours.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtHours.Name = "txtHours";
            this.txtHours.ReadOnly = true;
            this.txtHours.Size = new System.Drawing.Size(68, 20);
            this.txtHours.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 215);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Last Name";
            // 
            // txtLast
            // 
            this.txtLast.Location = new System.Drawing.Point(106, 215);
            this.txtLast.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtLast.Name = "txtLast";
            this.txtLast.ReadOnly = true;
            this.txtLast.Size = new System.Drawing.Size(68, 20);
            this.txtLast.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(199, 215);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Department";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(281, 211);
            this.txtDepartment.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(68, 20);
            this.txtDepartment.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(377, 214);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Graders Payment";
            // 
            // lblpayment
            // 
            this.lblpayment.AutoSize = true;
            this.lblpayment.Location = new System.Drawing.Point(465, 158);
            this.lblpayment.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblpayment.Name = "lblpayment";
            this.lblpayment.Size = new System.Drawing.Size(0, 13);
            this.lblpayment.TabIndex = 17;
            this.lblpayment.Click += new System.EventHandler(this.lblpayment_Click);
            // 
            // txtPayment
            // 
            this.txtPayment.Location = new System.Drawing.Point(469, 208);
            this.txtPayment.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.ReadOnly = true;
            this.txtPayment.Size = new System.Drawing.Size(68, 20);
            this.txtPayment.TabIndex = 18;
            this.txtPayment.TextChanged += new System.EventHandler(this.txtPayment_TextChanged);
            // 
            // btnGreater
            // 
            this.btnGreater.Location = new System.Drawing.Point(419, 83);
            this.btnGreater.Name = "btnGreater";
            this.btnGreater.Size = new System.Drawing.Size(85, 47);
            this.btnGreater.TabIndex = 19;
            this.btnGreater.Text = "Display graders with hours > 0";
            this.btnGreater.UseVisualStyleBackColor = true;
            this.btnGreater.Click += new System.EventHandler(this.btnGreater_Click);
            // 
            // btnEqualto
            // 
            this.btnEqualto.Location = new System.Drawing.Point(419, 146);
            this.btnEqualto.Name = "btnEqualto";
            this.btnEqualto.Size = new System.Drawing.Size(85, 54);
            this.btnEqualto.TabIndex = 20;
            this.btnEqualto.Text = "Display Graders with 0 hours";
            this.btnEqualto.UseVisualStyleBackColor = true;
            this.btnEqualto.Click += new System.EventHandler(this.btnEqualto_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 345);
            this.Controls.Add(this.btnEqualto);
            this.Controls.Add(this.btnGreater);
            this.Controls.Add(this.txtPayment);
            this.Controls.Add(this.lblpayment);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtDepartment);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtLast);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtHours);
            this.Controls.Add(this.txtPay);
            this.Controls.Add(this.txtFirst);
            this.Controls.Add(this.txtGraderId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.dgvGraders);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_Grader);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGraders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Grader;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView dgvGraders;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtGraderId;
        private System.Windows.Forms.TextBox txtFirst;
        private System.Windows.Forms.TextBox txtPay;
        private System.Windows.Forms.TextBox txtHours;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtLast;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblpayment;
        private System.Windows.Forms.TextBox txtPayment;
        private System.Windows.Forms.Button btnGreater;
        private System.Windows.Forms.Button btnEqualto;
    }
}

