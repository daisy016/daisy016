﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW3
{
    public partial class frmNewGrader : Form
    {
        Grader c = null;

        public frmNewGrader()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //TODO: populate the client object.
            c = new Grader();
            try
            {
                c.GraderID = int.Parse(txtGraderId.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter a number.");
                return;
            }
            c.FirstName = txtFirst.Text;
            c.LastName = txtLast.Text;
            try
            {
                c.Hours = int.Parse(txtHours.Text);
            }catch (Exception)
            {
                MessageBox.Show("Please enter a number.");
            }
            try
            {
                c.HourlyPay = decimal.Parse(txtPay.Text);
            }catch (Exception)
            {
                MessageBox.Show("Please enter a number.");
            }
           
            //c.State = txtState.Text;
            c.Department = cbxDepartment.SelectedValue.ToString();
            
            try
            {
                GradersEntities container = new GradersEntities();
                container.Graders.Add(c);
                container.SaveChanges();

                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            this.Close();
        }

       

        private void frmNewGrader_Load_1(object sender, EventArgs e)
        {
            try
            {
                GradersEntities container = new GradersEntities();
                List<Department> departments = container.Departments.ToList();
                cbxDepartment.DisplayMember = "DepartmentName";
                cbxDepartment.ValueMember = "DepartmentCode";
                cbxDepartment.DataSource = departments;
            }catch (Exception ex)
            {
                MessageBox.Show("System error: " + ex.Message);
            }
                
                
            
        }
    }
}






