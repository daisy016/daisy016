package edu.txstate.dsm117.cabfareandcarwash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;


public class CarWash extends AppCompatActivity {
    public static double EXTERIOR_WASH = 10.5;

    public static double EXTERIOR_INTERIOR = 15;

    double numberOfWashes;
    double totalCalcWash;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_wash);

        EditText numberofwashes = findViewById(R.id.txtNumberofWashes);
        RadioButton exterior = findViewById(R.id.rdExterior);
        RadioButton exteriorInterior = findViewById(R.id.rdExteriorInterior);
        Button calculate = findViewById(R.id.btnCalcWash);
        TextView results = findViewById(R.id.txtCalcWashResults);

        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ///////
                numberOfWashes = Double.parseDouble(numberofwashes.getText().toString());

                if (exterior.isChecked()) {
                    totalCalcWash = numberOfWashes * EXTERIOR_WASH;

                }else {
                    totalCalcWash = numberOfWashes * EXTERIOR_INTERIOR;
                }

                DecimalFormat formatter = new DecimalFormat("$###,###.##");
                results.setText(formatter.format(totalCalcWash));

                ////////
            }
        });

    }
}
