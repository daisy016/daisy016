package edu.txstate.dsm117.cabfareandcarwash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class CabFare extends AppCompatActivity {

    int intDistance;

    double dblTotalCost;

    public static double COST_PER_MILE = 3.25;

    public static double INITIAL_FEE = 5.50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cab_fare);

        EditText distance = findViewById(R.id.txtDistance);
        Spinner group = findViewById(R.id.spnGroup);
        TextView results = findViewById(R.id.txtResultsFare);
        Button calculate = findViewById(R.id.btnCalculateFare);

        //event handling
        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strDistance = distance.getText().toString();
                intDistance = Integer.parseInt(strDistance);
                dblTotalCost = intDistance * COST_PER_MILE + INITIAL_FEE;
                //RESULTS DISPLAY
                DecimalFormat formatter = new DecimalFormat("$###,###.##");
                results.setText(formatter.format(dblTotalCost) + ", " + group.getSelectedItem().toString());
            }

        });
    }
}