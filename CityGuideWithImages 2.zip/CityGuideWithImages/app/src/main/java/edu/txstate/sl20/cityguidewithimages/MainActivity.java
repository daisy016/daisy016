package edu.txstate.sl20.cityguidewithimages;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends ListActivity {
    ArrayList<Attraction> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        //Make 3 attractions
        list = new ArrayList<Attraction>();
        Attraction a1 = new Attraction();
        a1.setId(1);
        a1.setName("bridge");
        a1.setImage(R.drawable.bridge);
        list.add(a1);
        Attraction a2= new Attraction();
        a2.setId(2);
        a2.setName("pier");
        a2.setImage(R.drawable.pier);
        list.add(a2);

        Attraction a3= new Attraction();
        a3.setId(3);
        a3.setName("tower");
        a3.setImage(R.drawable.tower);
        list.add(a3);
        setListAdapter(new AttractionAdaptor(this, R.layout.attraction_item, list));


    }
}