package edu.txstate.sl20.cityguidewithimages;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;


public class AttractionAdaptor extends ArrayAdapter<Attraction> {
    private Context context;
    private int resource;
    public AttractionAdaptor(@NonNull Context context, int resource, @NonNull List<Attraction> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        convertView = mInflater.inflate(resource, null);

        TextView name = convertView.findViewById(R.id.txtName);
        name.setText(getItem(position).getName());
        ImageView image = convertView.findViewById(R.id.imageAttraction);
        image.setImageResource(getItem(position).getImage());

        return convertView;
    }
}
