package edu.txstate.dsm117.exam14321;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class TutorSelection extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_selection);

        Spinner group = findViewById(R.id.spnGroup);
        Button select = findViewById(R.id.btnSelect);
        TextView tutor = findViewById(R.id.txtLastTutors);

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tutor.setText(group.getSelectedItem().toString());

            }


        });


    }
}