package edu.txstate.dsm117.exam14321;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {


    int intHour;

    double dblTotalCost;


    public static double PER_HOUR = 3.5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText hours = findViewById(R.id.txtNumberOfHours);
        Button calculate = findViewById(R.id.btnCalcPayment);
        TextView results = findViewById(R.id.txtResults);
        Button screen = findViewById(R.id.btnSelectTutor);
        screen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (intHour>20){
                    startActivity(new Intent(MainActivity.this, TutorSelection.class));
                }else {
                    results.setText("At least 20 hours are required to select a tutor.");
                }


            }

        });




        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strHours = hours.getText().toString();
                intHour = Integer.parseInt(strHours);
                dblTotalCost = intHour * PER_HOUR;
                //Results Display
                DecimalFormat formatter = new DecimalFormat("$###,###.##");
                results.setText(formatter.format(dblTotalCost));


            }


        });
    }
}