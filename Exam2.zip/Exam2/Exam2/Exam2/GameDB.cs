﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam2
{
    public class GameDB
    {
        public static void deleteGame(Game game)
        {
            //delete using embedded sql
            string sqlString = "delete from game where GameID = @id";
            //get a connection object
            SqlConnection connection = DBConnection.getConnection();
            //prepare for sql statement 
            try
            {
                SqlCommand deleteCommand = new SqlCommand(sqlString, connection);
                deleteCommand.Parameters.AddWithValue("@id", game.GameID);
                connection.Open();
                deleteCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);

                
                throw ex;

            }
            try
            {
                connection.Close();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);
            }

        }
        public static void addGame(Game game)
        {
            //Insert using embedded sql
            string sqlString = "insert into game values(@id, @title, @price, @discount) ";

            //Get a connetion object
            SqlConnection connection = DBConnection.getConnection();
            //Prepare for a SQL statement 
            try
            {
                SqlCommand insertCommand = new SqlCommand(sqlString, connection);
                insertCommand.Parameters.AddWithValue("@id", game.GameID);
                insertCommand.Parameters.AddWithValue("@title", game.Title);
                insertCommand.Parameters.AddWithValue("@price", game.Price);
                insertCommand.Parameters.AddWithValue("@discount", game.Discount);
            
                connection.Open();
                insertCommand.ExecuteNonQuery();
            }
            catch (Exception ex)

            {
                //log the error.
                Console.WriteLine(ex);


                throw ex;
            }
            try
            {
                connection.Close();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);
            }
        }
        public static List<Game> getAllGames()
        {
            List<Game> list = new List<Game>();
            string sqlString = "select * from game";


            //Get a connetion object
            SqlConnection connection = DBConnection.getConnection();

            //Prepare for a SQL statement 
            SqlCommand selectCommand = new SqlCommand(sqlString, connection);
            SqlDataReader reader;

            //Execute the SQL command
            try
            {
                connection.Open();
                reader = selectCommand.ExecuteReader();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);

                //throw the error to the presntation layer
                throw new Exception("database server error");
            }

            
            while (reader.Read()) //reader.Read() return true if there is a recored
            {
                Game ct;
                try
                {
                    ct = new Game();
                    ct.GameID = (string)reader["GameID"]; // column name is case sentitive 
                    ct.Title = (string)reader["Title"];
                    ct.Price = (decimal)reader["Price"];
                    ct.Discount = (decimal)reader["Discount"];
                 
                }
                catch (Exception ex)
                {
                    //log the error.
                    Console.WriteLine(ex);
                    return null;

                    //throw the error to the presntation layer
                    throw new Exception("data error");

                }
                list.Add(ct);
            }

            try
            {
                connection.Close();
            }
            catch (Exception ex)
            {
                //log the error.
                Console.WriteLine(ex);
            }
            return list;
        }
    }




}
