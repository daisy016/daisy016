﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam2
{
    public partial class frmNewGame : Form
    {
        Game c = null;
        public frmNewGame()
        {
            InitializeComponent();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            c = new Game();
            c.GameID = txtGameId.Text;
            c.Title = txtTitle.Text;
            try
            {
                c.Price = decimal.Parse(txtPrice.Text);
            }catch (Exception)
            {
                MessageBox.Show("Please enter a number");
            }
            try
            {
                c.Discount = decimal.Parse(txtDiscount.Text);

            }catch (Exception)
            {
                MessageBox.Show("Please enter a number");
            }
            
            try
            {
                GameDB.addGame(c);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.Close();
           
        }

        private void frmNewGame_Load(object sender, EventArgs e)
        {
            List<Game> games = GameDB.getAllGames();
        }
    }
}
