﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exam2
{
    public partial class Form1 : Form
    {
        List<Game> games = new List<Game>();
        Game selectedGame = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            showGames();
        }

        private void showGames()
        {
            try
            {
                games = GameDB.getAllGames();
                games = games.OrderBy(x => x.GameID).ToList();
                var values = games.Select(x => new { x.GameID, x.Title, x.Price, x.Discount}).ToList();
                dvgGames.DataSource = values;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (selectedGame != null)
                {
                    GameDB.deleteGame(selectedGame);
                    showGames();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Game_Click(object sender, EventArgs e)
        {
            frmNewGame form = new frmNewGame();
            form.ShowDialog();

            showGames();
        }

        private void dvgGames_SelectionChanged(object sender, EventArgs e)
        {
            int selectedIndex = dvgGames.CurrentRow.Index;


            if (selectedIndex >=0)
            {
                selectedGame = games.ElementAt(selectedIndex);
                txtGameId.Text = selectedGame.GameID;
                txtTitle.Text = selectedGame.Title;
                txtPrice.Text = selectedGame.Price.ToString();
                txtDiscount.Text = selectedGame.Discount.ToString();
                MessageBox.Show((selectedGame.GetSalePrice().ToString("c")), "saleprice");
            }
        }
    }
}
